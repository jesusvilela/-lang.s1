package com.example.topostrasgo.unified

import kotlin.math.*

/**
 * §T|LEVEL: Single level of the disk tower — a Poincaré ball with its own
 * curvature c_k and index k. Wraps the primitives in [HyperbolicOps] but
 * parameterizes them by a per-level curvature so mixed-curvature towers
 * (A28 of the Tower dialect) are expressible.
 *
 * [HyperbolicOps] hardcodes `const val C = 1.0f`; this class replicates the
 * essential operations with a runtime `curvature` while preserving numerical
 * behavior when curvature == 1.0.
 *
 * Corresponds to §|DIALECT_TOWER|SORTS_EXT sort.Level and to Level_k in
 * Tower dialect v2.5.
 */
class PoincareDisk(
    val level: Int,
    val curvature: Float = 1.0f,
    val dim: Int = 8
) {
    /** §T|LEVEL: Boundary clip — stays strictly inside the unit ball */
    val clip: Float = 1.0f - 1e-5f

    init {
        require(curvature > 0f) { "Curvature c_k must be positive (κ = -c < 0)" }
        require(dim > 0) { "Dimension must be positive" }
    }

    /** Origin of this level — used as default fixed point for elliptic rotations. */
    fun origin(): FloatArray = FloatArray(dim)

    /** §T|LEVEL: Conformal factor λ_x = 2c / (1 − c|x|²) at curvature c_k. */
    fun conformalFactor(x: FloatArray): Float {
        val x2 = HyperbolicOps.dot(x, x)
        val den = 1f - curvature * x2
        return 2f * curvature / (if (abs(den) < 1e-10f) 1e-10f else den)
    }

    /**
     * §T|LEVEL: Möbius addition x ⊕_c y at curvature c_k.
     * Reduces to [HyperbolicOps.mobiusAdd] when c_k = 1.
     */
    fun mobiusAdd(x: FloatArray, y: FloatArray): FloatArray {
        require(x.size == y.size) { "Dimensions must match" }
        val c = curvature
        val xy = HyperbolicOps.dot(x, y)
        val x2 = HyperbolicOps.dot(x, x)
        val y2 = HyperbolicOps.dot(y, y)
        val scale1 = 1f + 2f * c * xy + c * y2
        val scale2 = 1f - c * x2
        val den = 1f + 2f * c * xy + c * c * x2 * y2
        val safeDen = if (abs(den) < 1e-10f) 1e-10f else den
        return FloatArray(x.size) { i -> (scale1 * x[i] + scale2 * y[i]) / safeDen }
    }

    /** §T|LEVEL: Exponential map exp_x(v) on Level_k. */
    fun expMap(x: FloatArray, v: FloatArray): FloatArray {
        require(x.size == v.size) { "Dimensions must match" }
        val lam = conformalFactor(x)
        val nv = HyperbolicOps.norm(v)
        if (nv < 1e-12f) return x.copyOf()
        val sqrtC = sqrt(curvature)
        val t = tanh((sqrtC * lam * nv / 2f).toDouble()).toFloat()
        val scale = t / (nv * sqrtC)
        val tang = FloatArray(v.size) { scale * v[it] }
        return project(mobiusAdd(x, tang))
    }

    /** §T|LEVEL: Logarithmic map log_x(y) on Level_k. */
    fun logMap(x: FloatArray, y: FloatArray): FloatArray {
        require(x.size == y.size) { "Dimensions must match" }
        val lam = conformalFactor(x)
        val negX = FloatArray(x.size) { -x[it] }
        val diff = mobiusAdd(negX, y)
        val r = HyperbolicOps.norm(diff)
        if (r < 1e-12f) return FloatArray(x.size)
        val sqrtC = sqrt(curvature)
        val arg = (sqrtC * r).coerceAtMost(1f - 1e-9f)
        val sc = (2f / (sqrtC * lam)) * atanh(arg)
        return FloatArray(diff.size) { sc * diff[it] / r }
    }

    /** §T|LEVEL: Poincaré geodesic distance at curvature c_k. */
    fun distance(a: FloatArray, b: FloatArray): Float {
        require(a.size == b.size) { "Dimensions must match" }
        val c = curvature
        var sqDist = 0f; var a2 = 0f; var b2 = 0f
        for (i in a.indices) {
            val d = a[i] - b[i]
            sqDist += d * d
            a2 += a[i] * a[i]
            b2 += b[i] * b[i]
        }
        val num = 2f * c * sqDist
        val den = (1f - c * a2) * (1f - c * b2)
        val safeDen = if (abs(den) < 1e-10f) 1e-10f else den
        val arg = 1f + num / safeDen
        return acosh(arg.coerceAtLeast(1f)) / sqrt(c)
    }

    /**
     * §T|LEVEL: Project into open ball at this level's curvature.
     * Ball boundary is ||x|| < 1/√c; project inward at margin `clip`.
     */
    fun project(v: FloatArray): FloatArray {
        val maxNorm = clip / sqrt(curvature)
        val r = HyperbolicOps.norm(v)
        return if (r >= maxNorm) FloatArray(v.size) { v[it] * maxNorm / r } else v.copyOf()
    }

    /** §T|LEVEL: σ1 boundary check — verdict BLOCK if any norm ≥ 0.999 / √c. */
    fun sigma1(x: FloatArray): Boolean {
        val maxNorm = 0.999f / sqrt(curvature)
        return HyperbolicOps.norm(x) < maxNorm
    }

    // Private Float wrappers for math ops (Kotlin stdlib defaults to Double)
    private fun atanh(x: Float): Float {
        val cx = x.coerceIn(-0.99999f, 0.99999f)
        return 0.5f * ln((1f + cx) / (1f - cx))
    }

    private fun acosh(x: Float): Float {
        val safe = x.coerceAtLeast(1f)
        return ln(safe + sqrt(safe * safe - 1f))
    }
}
