package com.example.topostrasgo.unified

import kotlin.math.*

/**
 * §T|FMIX: Double-fibration compatibility law, realizing §|DIALECT_TOWER|
 * COMPATIBILITY_LAW. This is the load-bearing invariant that distinguishes
 * a genuine 2-fibration (vertical × horizontal as a single geometric object)
 * from two independent bundles glued at shared disks.
 *
 * For a (vertical, horizontal) rectangle at level k with peers (p, q):
 *
 *              H_{k+1,p',q'}
 *   Peer_{k+1,p'} ─────────────→ Peer_{k+1,q'}
 *        ↑                              ↑
 *   V_{k,k+1}                      V_{k,k+1}
 *        │                              │
 *   Peer_{k,p} ─────────────────→ Peer_{k,q}
 *              H_{k,p,q}
 *
 * F_mix(k, p, q) is the defect:
 *    || lift_k ∘ H_{k,p,q} (x) − H_{k+1,p',q'} ∘ lift_k (x) ||_{Level_{k+1}}
 * where p' = liftPeer(k, p), q' = liftPeer(k, q) mapping peer indices
 * across levels (supplied by caller — typically identity when peer counts match).
 *
 * σ22 passes iff F_mix < ε_mix for all sampled rectangles.
 *
 * Reference: §-LANG v2.5 Tower dialect, axiom A31, invariant σ22.
 */
object TowerCompatibility {

    /** §T|FMIX: Default compatibility threshold ε_mix (from dialect spec). */
    const val DEFAULT_EPSILON_MIX: Float = 0.05f

    /**
     * §T|FMIX: Compute F_mix for a single (vertical × horizontal) rectangle.
     *
     * Caller supplies [liftPeer], which maps a peer index at level k to the
     * corresponding peer index at level k+1. For simple towers with equal
     * peer counts per level, `{ _, p -> p }` is the identity mapping.
     *
     * @return ||lift∘htransport(x) − htransport∘lift(x)||_{Level_{k+1}}
     */
    fun computeFMix(
        tower: DiskTower,
        levelFrom: Int,
        peerP: Int,
        peerQ: Int,
        liftPeer: (level: Int, peerIdx: Int) -> Int = { _, p -> p }
    ): Float {
        require(levelFrom in 0 until tower.numLevels - 1) {
            "Rectangle requires level < N-1; got $levelFrom"
        }
        val levelTo = levelFrom + 1

        // Peer p's current state on Level_k
        val x = tower.peers[levelFrom][peerP]

        // Path 1: horizontal first, then lift
        val hCh = tower.peerChannel(levelFrom, peerP, peerQ)
            ?: error("Missing H channel at level $levelFrom peers $peerP→$peerQ")
        val pathHV: FloatArray = tower.lift(levelFrom, hCh.traverse(x))

        // Path 2: lift first, then horizontal at level above
        val pPrime = liftPeer(levelFrom, peerP)
        val qPrime = liftPeer(levelFrom, peerQ)
        val hChUp = tower.peerChannel(levelTo, pPrime, qPrime)
            ?: error("Missing H channel at level $levelTo peers $pPrime→$qPrime")
        val pathVH: FloatArray = hChUp.traverse(tower.lift(levelFrom, x))

        // Defect measured in the upper level's hyperbolic metric
        return tower.levels[levelTo].distance(pathHV, pathVH)
    }

    /**
     * §T|FMIX: Compute F_mix over all rectangles in the tower and aggregate.
     *
     * Returns (maxDefect, meanDefect, numRectangles). σ22 passes iff
     * maxDefect < ε_mix. The mean is informational for regularizer design.
     */
    fun surveyFMix(
        tower: DiskTower,
        liftPeer: (level: Int, peerIdx: Int) -> Int = { _, p -> p }
    ): FMixSurvey {
        if (tower.numLevels < 2) return FMixSurvey(0f, 0f, 0)

        var maxDefect = 0f
        var sumDefect = 0f
        var count = 0

        for (k in 0 until tower.numLevels - 1) {
            val M_k = tower.peersPerLevel[k]
            val M_kp1 = tower.peersPerLevel[k + 1]
            for (p in 0 until M_k) {
                val pUp = liftPeer(k, p)
                if (pUp !in 0 until M_kp1) continue
                for (q in 0 until M_k) {
                    if (p == q) continue
                    val qUp = liftPeer(k, q)
                    if (qUp !in 0 until M_kp1) continue
                    // Skip if required channels are not installed
                    if (tower.peerChannel(k, p, q) == null) continue
                    if (tower.peerChannel(k + 1, pUp, qUp) == null) continue

                    val defect = try {
                        computeFMix(tower, k, p, q, liftPeer)
                    } catch (e: IllegalStateException) {
                        continue
                    }
                    if (defect > maxDefect) maxDefect = defect
                    sumDefect += defect
                    count += 1
                }
            }
        }

        val mean = if (count == 0) 0f else sumDefect / count.toFloat()
        return FMixSurvey(maxDefect, mean, count)
    }

    /**
     * §T|FMIX: σ22 check — compatibility law holds iff max defect < ε_mix.
     */
    fun sigma22Check(
        tower: DiskTower,
        epsilonMix: Float = DEFAULT_EPSILON_MIX,
        liftPeer: (level: Int, peerIdx: Int) -> Int = { _, p -> p }
    ): Sigma22Result {
        val survey = surveyFMix(tower, liftPeer)
        val passed = survey.maxDefect < epsilonMix
        return Sigma22Result(passed, survey, epsilonMix)
    }

    /**
     * §T|FMIX: Regularizer target — squared-max defect for training-time use.
     * Minimizing this drives F_mix → 0 (flat 2-connection, strict commutation).
     * Alternatively, if the architecture wants non-zero content-dependent
     * coupling, regularize toward a target value rather than zero.
     */
    fun fMixRegularizer(
        tower: DiskTower,
        target: Float = 0f,
        liftPeer: (level: Int, peerIdx: Int) -> Int = { _, p -> p }
    ): Float {
        val survey = surveyFMix(tower, liftPeer)
        val d = survey.maxDefect - target
        return d * d
    }

    // ────────────────────────────────────────────────────────────────────
    // §T|FMIX: Result types
    // ────────────────────────────────────────────────────────────────────

    data class FMixSurvey(
        val maxDefect: Float,
        val meanDefect: Float,
        val numRectangles: Int
    )

    data class Sigma22Result(
        val passed: Boolean,
        val survey: FMixSurvey,
        val epsilonMix: Float
    ) {
        fun verdict(): String = when {
            passed && survey.maxDefect < epsilonMix * 0.1f -> "COMMIT"
            passed -> "COMMIT"
            survey.maxDefect < epsilonMix * 3f -> "ROLLBACK"
            else -> "BLOCK"
        }

        override fun toString(): String =
            "σ22[${if (passed) "PASS" else "FAIL"}] " +
            "max=${"%.4f".format(survey.maxDefect)} " +
            "mean=${"%.4f".format(survey.meanDefect)} " +
            "ε=${epsilonMix} " +
            "rectangles=${survey.numRectangles} " +
            "verdict=${verdict()}"
    }
}
