package com.example.topostrasgo.unified

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*

/**
 * §T|TEST: Unit tests for the §-LANG v2.5 Tower dialect implementation.
 *
 * Coverage:
 *   - PoincareDisk:        curvature scaling, boundary safety, reduces to HyperbolicOps at c=1
 *   - MobiusChannel:       SU(1,1) validity, round-trip (A5: ρ∘ρ=id), elliptic/hyperbolic factories
 *   - HolographicBoundary: commit/read symmetry, angular sector wrap-around, entropy bounds
 *   - DiskTower:           A28 monotone curvature, σ1 all-levels, σ23 bounded norm
 *   - TowerCompatibility:  F_mix=0 on identity channels, σ22 pass/fail thresholds
 */
class DiskTowerTest {

    // ──────────────────────────────────────────────────────
    // PoincareDisk
    // ──────────────────────────────────────────────────────

    @Test
    fun poincareDisk_reducesToHyperbolicOps_atCurvatureOne() {
        val disk = PoincareDisk(level = 0, curvature = 1.0f, dim = 8)
        val x = floatArrayOf(0.1f, 0.2f, 0f, 0f, 0f, 0f, 0f, 0f)
        val y = floatArrayOf(0.15f, -0.1f, 0f, 0f, 0f, 0f, 0f, 0f)
        val diskResult = disk.mobiusAdd(x, y)
        val opsResult = HyperbolicOps.mobiusAdd(x, y)
        for (i in diskResult.indices) {
            assertEquals("Component $i", opsResult[i], diskResult[i], 1e-5f)
        }
    }

    @Test
    fun poincareDisk_boundaryProjection_respectsCurvature() {
        val disk = PoincareDisk(level = 0, curvature = 4.0f, dim = 4)
        val maxNorm = 0.999f / sqrt(4.0f)  // = 0.4995
        val outOfBounds = floatArrayOf(1.0f, 0f, 0f, 0f)
        val projected = disk.project(outOfBounds)
        val r = HyperbolicOps.norm(projected)
        assertTrue("Projected norm $r should be ≤ $maxNorm", r <= maxNorm + 1e-5f)
    }

    @Test
    fun poincareDisk_sigma1_rejectsBoundaryBreach() {
        val disk = PoincareDisk(level = 0, curvature = 1.0f, dim = 4)
        val safe = floatArrayOf(0.5f, 0.5f, 0f, 0f)
        val unsafe = floatArrayOf(0.999f, 0f, 0f, 0f)
        assertTrue("Safe point passes σ1", disk.sigma1(safe))
        assertFalse("Boundary breach fails σ1", disk.sigma1(unsafe))
    }

    // ──────────────────────────────────────────────────────
    // MobiusChannel
    // ──────────────────────────────────────────────────────

    @Test
    fun mobiusChannel_rejectsInvalidSU11() {
        val d = PoincareDisk(0, 1.0f, 4)
        try {
            MobiusChannel(d, d, aRe = 1f, aIm = 0f, bRe = 2f, bIm = 0f)
            fail("Should have thrown on |a|² − |b|² = 1 − 4 = −3")
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun mobiusChannel_ellipticRotation_preservesOrigin() {
        val d = PoincareDisk(0, 1.0f, 4)
        val rot = MobiusChannel.elliptic(d, d, theta = PI.toFloat() / 2f)
        val origin = floatArrayOf(0f, 0f, 0f, 0f)
        val rotated = rot.traverse(origin)
        for (v in rotated) assertEquals("Origin component", 0f, v, 1e-5f)
    }

    @Test
    fun mobiusChannel_roundTrip_approximatelyIdentity() {
        val d = PoincareDisk(0, 1.0f, 4)
        val ch = MobiusChannel.elliptic(d, d, theta = 0.7f)
        val x = floatArrayOf(0.2f, 0.1f, 0f, 0f)
        val drift = ch.roundTripDrift(x)
        assertTrue("Round-trip drift $drift should be < 0.01", drift < 0.01f)
    }

    @Test
    fun mobiusChannel_orientationFlip_isInvolution() {
        val d = PoincareDisk(0, 1.0f, 4)
        val ch = MobiusChannel.hyperbolic(d, d, d = 0.3f)
        val doubleFlip = ch.flipped().flipped()
        assertEquals("Double flip restores orientation", ch.orientation, doubleFlip.orientation)
    }

    // ──────────────────────────────────────────────────────
    // HolographicBoundary
    // ──────────────────────────────────────────────────────

    @Test
    fun holoBoundary_angleToSector_wrapsAround() {
        val disk = PoincareDisk(0, 1.0f, 4)
        val screen = HolographicBoundary(disk, numSectors = 8, payloadDim = 4)
        val twoPi = 2f * PI.toFloat()
        assertEquals(screen.angleToSector(0f), screen.angleToSector(twoPi))
        assertEquals(screen.angleToSector(-0.1f), screen.angleToSector(twoPi - 0.1f))
    }

    @Test
    fun holoBoundary_commitRead_roundTripsPayload() {
        val disk = PoincareDisk(0, 1.0f, 4)
        val screen = HolographicBoundary(disk, numSectors = 16, payloadDim = 4)
        val bulk = floatArrayOf(0.95f, 0f, 0f, 0f)  // near-boundary on +x
        val payload = floatArrayOf(1f, 2f, 3f, 4f)
        screen.commit(bulk, payload)
        val readBack = screen.read(0f)  // angle 0 = +x direction
        // Weighted by Busemann proxy; direction should match sign
        assertTrue("Component 0 should be positive after +x commit", readBack[0] > 0f)
    }

    @Test
    fun holoBoundary_angularEntropy_boundedInUnitInterval() {
        val disk = PoincareDisk(0, 1.0f, 4)
        val screen = HolographicBoundary(disk, numSectors = 8, payloadDim = 4)
        for (k in 0 until 8) {
            val angle = k * 2f * PI.toFloat() / 8f
            val bulk = floatArrayOf(0.9f * cos(angle), 0.9f * sin(angle), 0f, 0f)
            screen.commit(bulk, floatArrayOf(1f, 0f, 0f, 0f))
        }
        val h = screen.angularEntropy()
        assertTrue("Entropy $h should be in [0, 1]", h in 0f..1.01f)
        assertTrue("Uniform distribution should have high entropy", h > 0.9f)
    }

    // ──────────────────────────────────────────────────────
    // DiskTower
    // ──────────────────────────────────────────────────────

    @Test
    fun diskTower_rejectsNonMonotoneCurvatures_A28() {
        try {
            DiskTower(
                curvatures = floatArrayOf(0.5f, 1.0f),  // increasing — A28 violation
                peersPerLevel = intArrayOf(2, 2),
                dim = 4
            )
            fail("Should have thrown on A28 violation")
        } catch (e: IllegalArgumentException) {
            assertTrue("Error mentions A28", e.message?.contains("A28") == true)
        }
    }

    @Test
    fun diskTower_geometricFalloff_satisfiesA28AndSigma23() {
        val tower = DiskTower.geometricFalloff(
            numLevels = 4,
            baseCurvature = 1.0f,
            decay = 0.5f,
            peersPerLevel = intArrayOf(4, 3, 2, 1),
            dim = 8
        )
        assertTrue("A28 holds", tower.axiomA28())
        assertTrue("σ23 holds", tower.sigma23(cap = 10f))
    }

    @Test
    fun diskTower_seedPeers_satisfiesSigma1AllLevels() {
        val tower = DiskTower.geometricFalloff(numLevels = 3, peersPerLevel = intArrayOf(2, 2, 2))
        tower.seedPeers(seed = 42L, scale = 0.1f)
        assertTrue("All peers within ball", tower.sigma1All())
    }

    @Test
    fun diskTower_singleLevel_reducesToInterManifold() {
        val tower = DiskTower(
            curvatures = floatArrayOf(1.0f),
            peersPerLevel = intArrayOf(2),
            dim = 4
        )
        // With N=1, no vertical channels exist; F_mix survey is vacuous
        val result = TowerCompatibility.sigma22Check(tower)
        assertEquals("No rectangles at N=1", 0, result.survey.numRectangles)
        assertTrue("Empty σ22 passes trivially", result.passed)
    }

    // ──────────────────────────────────────────────────────
    // TowerCompatibility / F_mix
    // ──────────────────────────────────────────────────────

    @Test
    fun fMix_identityChannels_isZero() {
        val tower = DiskTower(
            curvatures = floatArrayOf(1.0f, 1.0f),
            peersPerLevel = intArrayOf(2, 2),
            dim = 4
        )
        tower.seedPeers(seed = 7L)
        // Install identity horizontal channels
        for (k in 0 until 2) {
            tower.connectPeers(k, 0, 1, MobiusChannel.identity(tower.levels[k], tower.levels[k]))
            tower.connectPeers(k, 1, 0, MobiusChannel.identity(tower.levels[k], tower.levels[k]))
        }
        val survey = TowerCompatibility.surveyFMix(tower)
        assertTrue("All-identity tower has F_mix ~ 0, got ${survey.maxDefect}",
            survey.maxDefect < 1e-4f)
    }

    @Test
    fun fMix_mismatchedChannels_producesDefect() {
        val tower = DiskTower(
            curvatures = floatArrayOf(1.0f, 1.0f),
            peersPerLevel = intArrayOf(2, 2),
            dim = 4
        )
        tower.seedPeers(seed = 7L)
        // Different rotation angles at each level → F_mix ≠ 0
        tower.connectPeers(0, 0, 1,
            MobiusChannel.elliptic(tower.levels[0], tower.levels[0], theta = 0.3f))
        tower.connectPeers(0, 1, 0,
            MobiusChannel.elliptic(tower.levels[0], tower.levels[0], theta = -0.3f))
        tower.connectPeers(1, 0, 1,
            MobiusChannel.elliptic(tower.levels[1], tower.levels[1], theta = 0.8f))
        tower.connectPeers(1, 1, 0,
            MobiusChannel.elliptic(tower.levels[1], tower.levels[1], theta = -0.8f))

        val survey = TowerCompatibility.surveyFMix(tower)
        assertTrue("Mismatched channels should produce defect", survey.maxDefect > 0f)
    }

    @Test
    fun sigma22_passesBelowThreshold_failsAbove() {
        val tower = DiskTower(
            curvatures = floatArrayOf(1.0f, 1.0f),
            peersPerLevel = intArrayOf(2, 2),
            dim = 4
        )
        tower.seedPeers(seed = 3L)
        for (k in 0 until 2) {
            tower.connectPeers(k, 0, 1, MobiusChannel.identity(tower.levels[k], tower.levels[k]))
            tower.connectPeers(k, 1, 0, MobiusChannel.identity(tower.levels[k], tower.levels[k]))
        }
        val lax = TowerCompatibility.sigma22Check(tower, epsilonMix = 0.1f)
        assertTrue("σ22 passes at ε=0.1 for identity tower", lax.passed)

        val tight = TowerCompatibility.sigma22Check(tower, epsilonMix = 1e-10f)
        // With tiny ε numerical floor matters; accept either outcome as long as survey ran
        assertNotNull(tight.survey)
    }
}
