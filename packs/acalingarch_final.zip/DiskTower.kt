package com.example.topostrasgo.unified

import kotlin.math.*

/**
 * §T|TOWER: Vertical tower of Poincaré disks with horizontal peer interfaces
 * and per-level holographic screens. Realizes §|DIALECT_TOWER|TOWER_STRUCTURE
 * from §-LANG v2.5.
 *
 * At each level k ∈ [0, N−1]:
 *   - Level_k is a [PoincareDisk] with curvature c_k (monotone by A28)
 *   - Peers M_k peer points live on Level_k
 *   - Screen_k is a [HolographicBoundary] on Level_k's S¹
 *   - VChannel_{k,k+1} links Level_k ↔ Level_{k+1} (adjacent only)
 *   - HChannel_{k,p,q} links peer p ↔ peer q within Level_k
 *
 * Single-level (N=1) usage reduces exactly to §|DIALECT_TOWER|INTER_MANIFOLD
 * v2.4 semantics — no behavior change. Tower-specific logic activates only
 * when N ≥ 2.
 *
 * Design note: vertical channels are stored in-order (index k connects k↔k+1);
 * horizontal channels are keyed by (level, peerFrom, peerTo) and populated
 * lazily by [connectPeers].
 */
class DiskTower(
    val curvatures: FloatArray,
    val peersPerLevel: IntArray,
    val dim: Int = 8,
    val screenSectors: Int = 64
) {
    /** §T|TOWER: Number of levels in the tower. */
    val numLevels: Int = curvatures.size

    /** §T|TOWER: Level_0 ... Level_{N-1} from base to top. */
    val levels: List<PoincareDisk>

    /** §T|TOWER: Screens, one per level, attached at the Gromov boundary. */
    val screens: List<HolographicBoundary>

    /** §T|TOWER: Peer state — peers[k][p] is the current section for peer p on Level_k. */
    val peers: List<Array<FloatArray>>

    /** §T|TOWER: Vertical channels. vChannels[k] links Level_k → Level_{k+1}. */
    private val vChannels: MutableList<MobiusChannel> = mutableListOf()

    /** §T|TOWER: Horizontal channels keyed by (level, from, to). */
    private val hChannels: MutableMap<Triple<Int, Int, Int>, MobiusChannel> = mutableMapOf()

    init {
        require(numLevels >= 1) { "Tower must have at least one level" }
        require(peersPerLevel.size == numLevels) { "peersPerLevel must match numLevels" }
        require(peersPerLevel.all { it >= 1 }) { "Each level must have at least one peer" }

        // A28 compliance: curvatures must be monotone non-increasing
        for (k in 0 until numLevels - 1) {
            require(curvatures[k] >= curvatures[k + 1] - 1e-6f) {
                "A28 violated: c_$k=${curvatures[k]} < c_${k+1}=${curvatures[k+1]}"
            }
        }

        levels = (0 until numLevels).map { k -> PoincareDisk(k, curvatures[k], dim) }
        screens = levels.map { HolographicBoundary(it, screenSectors, dim) }
        peers = (0 until numLevels).map { k ->
            Array(peersPerLevel[k]) { FloatArray(dim) }
        }

        // Default: identity vertical channels between adjacent levels
        for (k in 0 until numLevels - 1) {
            vChannels.add(MobiusChannel.identity(levels[k], levels[k + 1]))
        }
    }

    // ────────────────────────────────────────────────────────────────────
    // §T|TOWER: Vertical channel management
    // ────────────────────────────────────────────────────────────────────

    /** §T|TOWER: Replace the vertical channel between Level_k and Level_{k+1}. */
    fun setVChannel(levelFrom: Int, channel: MobiusChannel) {
        require(levelFrom in 0 until numLevels - 1) { "Invalid vertical from=$levelFrom" }
        require(channel.source == levels[levelFrom]) { "Channel source mismatch" }
        require(channel.target == levels[levelFrom + 1]) { "Channel target mismatch" }
        vChannels[levelFrom] = channel
    }

    /** §T|TOWER: Access the vertical channel at position k (Level_k → Level_{k+1}). */
    fun vChannel(levelFrom: Int): MobiusChannel {
        require(levelFrom in 0 until numLevels - 1) { "Invalid vertical from=$levelFrom" }
        return vChannels[levelFrom]
    }

    /** §T|TOWER: Lift a point from Level_k to Level_{k+1}. */
    fun lift(levelFrom: Int, point: FloatArray): FloatArray =
        vChannel(levelFrom).traverse(point)

    /** §T|TOWER: Project a point from Level_{k+1} down to Level_k. */
    fun project(levelFrom: Int, point: FloatArray): FloatArray =
        vChannel(levelFrom).inverse().traverse(point)

    // ────────────────────────────────────────────────────────────────────
    // §T|TOWER: Horizontal peer channel management
    // ────────────────────────────────────────────────────────────────────

    /**
     * §T|TOWER: Install a horizontal channel between two peers at the same level.
     * Idempotent: overwrites any prior channel at the same (level, from, to).
     */
    fun connectPeers(level: Int, peerFrom: Int, peerTo: Int, channel: MobiusChannel) {
        require(level in 0 until numLevels) { "Invalid level=$level" }
        require(peerFrom in 0 until peersPerLevel[level]) { "Invalid peerFrom=$peerFrom" }
        require(peerTo in 0 until peersPerLevel[level]) { "Invalid peerTo=$peerTo" }
        require(channel.source == levels[level] && channel.target == levels[level]) {
            "Horizontal channel must have matching source/target level"
        }
        hChannels[Triple(level, peerFrom, peerTo)] = channel
    }

    /** §T|TOWER: Retrieve a peer channel, or null if not installed. */
    fun peerChannel(level: Int, peerFrom: Int, peerTo: Int): MobiusChannel? =
        hChannels[Triple(level, peerFrom, peerTo)]

    /** §T|TOWER: Transport peer p's state to peer q via the installed channel. */
    fun transportPeer(level: Int, peerFrom: Int, peerTo: Int): FloatArray {
        val ch = peerChannel(level, peerFrom, peerTo)
            ?: error("No channel between peers $peerFrom → $peerTo on level $level")
        return ch.traverse(peers[level][peerFrom])
    }

    // ────────────────────────────────────────────────────────────────────
    // §T|TOWER: Screen interface (delegates to per-level HolographicBoundary)
    // ────────────────────────────────────────────────────────────────────

    /** §T|TOWER: Commit peer state to the level's screen. Shorthand for pipe `|>`. */
    fun commitToScreen(level: Int, peer: Int, payload: FloatArray? = null) {
        val x = peers[level][peer]
        val p = payload ?: x
        screens[level].commit(x, p)
    }

    /** §T|TOWER: Read boundary measure at angle. Shorthand for pipe `|>` reverse. */
    fun readFromScreen(level: Int, angle: Float): FloatArray =
        screens[level].read(angle)

    // ────────────────────────────────────────────────────────────────────
    // §T|TOWER: Tick / evolve — one step over the whole tower
    // ────────────────────────────────────────────────────────────────────

    /**
     * §T|TOWER: One tick of the tower. Per level k:
     *   1. Evolve each peer via `evolvePeer` (supplied callback; typically FHN or swirler step)
     *   2. Commit each peer state to Screen_k
     *
     * Does NOT propagate through vertical or horizontal channels — that is
     * controlled externally so that the caller can interleave F_mix checks.
     * Returns Unit — mutates tower state in place.
     */
    fun tick(evolvePeer: (level: Int, peerIdx: Int, state: FloatArray) -> FloatArray) {
        for (k in 0 until numLevels) {
            for (p in 0 until peersPerLevel[k]) {
                peers[k][p] = levels[k].project(evolvePeer(k, p, peers[k][p]))
                commitToScreen(k, p)
            }
        }
    }

    // ────────────────────────────────────────────────────────────────────
    // §T|TOWER: σ invariants gated on tower structure
    // ────────────────────────────────────────────────────────────────────

    /** §T|TOWER: σ1 extension — check all peers on all levels remain in the ball. */
    fun sigma1All(): Boolean =
        (0 until numLevels).all { k ->
            (0 until peersPerLevel[k]).all { p -> levels[k].sigma1(peers[k][p]) }
        }

    /**
     * §T|TOWER: σ23 check — tower depth × curvature product bounded.
     * Returns true iff Σ_k c_k < cap (default cap = 10.0, tune per data).
     */
    fun sigma23(cap: Float = 10f): Boolean = curvatures.sum() < cap

    /** §T|TOWER: A28 reverification — curvatures still monotone non-increasing. */
    fun axiomA28(): Boolean {
        for (k in 0 until numLevels - 1) {
            if (curvatures[k] < curvatures[k + 1] - 1e-6f) return false
        }
        return true
    }

    /**
     * §T|TOWER: Initialize peers with small random perturbations around origin
     * for each level. Deterministic per seed. Respects per-level curvature bound.
     */
    fun seedPeers(seed: Long = 42L, scale: Float = 0.05f) {
        val rng = java.util.Random(seed)
        for (k in 0 until numLevels) {
            val maxR = (0.999f / sqrt(curvatures[k])) * 0.5f
            for (p in 0 until peersPerLevel[k]) {
                val v = FloatArray(dim) { ((rng.nextFloat() * 2f) - 1f) * scale * maxR }
                peers[k][p] = levels[k].project(v)
            }
        }
    }

    companion object {
        /**
         * §T|TOWER: Construct a mixed-curvature tower with geometric falloff.
         * c_k = c_0 · decay^k. Useful default for exploratory experiments.
         */
        fun geometricFalloff(
            numLevels: Int,
            baseCurvature: Float = 1.0f,
            decay: Float = 0.5f,
            peersPerLevel: IntArray = IntArray(numLevels) { 4 },
            dim: Int = 8
        ): DiskTower {
            require(decay in 0f..1f) { "Decay must be in [0, 1]" }
            val cs = FloatArray(numLevels) { k -> baseCurvature * decay.pow(k) }
            return DiskTower(cs, peersPerLevel, dim)
        }
    }
}
