package com.example.topostrasgo.unified

import kotlin.math.*

/**
 * §T|CHANNEL: Non-orientable Möbius channel between two disks, realizing
 * §|DIALECT_TOWER|VERTICAL_CHANNEL (A29) and §|DIALECT_TOWER|HORIZONTAL_PEER (A30).
 *
 * Structure group is PSU(1,1) ⋊ ℤ/2 — the ℤ/2 is the orientation flip from
 * INTER_MANIFOLD.one_traverse. A single traversal flips orientation; two
 * traversals are the identity (A5: ρ∘ρ = id).
 *
 * SU(1,1) representation: fractional linear transformation
 *   φ(z) = (a·z + b̄) / (b·z + ā)   with   |a|² − |b|² = 1
 * encoded as (aRe, aIm, bRe, bIm) for dim-2 complex action. For higher
 * dims the action is applied per 2D slice of coordinates (pairs (x_{2i}, x_{2i+1})
 * interpreted as complex numbers); odd-leftover coords are passed through.
 *
 * The `orientation` flag tracks ρ state: false = identity sheet, true = flipped.
 * A traversal toggles it; a round-trip restores it by A5.
 *
 * Corresponds to §|DIALECT_TOWER|SORTS_EXT sort.VChannel / sort.HChannel.
 */
class MobiusChannel(
    val source: PoincareDisk,
    val target: PoincareDisk,
    val aRe: Float,
    val aIm: Float,
    val bRe: Float,
    val bIm: Float,
    val orientation: Boolean = false
) {
    init {
        val det = aRe * aRe + aIm * aIm - (bRe * bRe + bIm * bIm)
        require(abs(det - 1f) < 1e-3f) {
            "SU(1,1) constraint violated: |a|² − |b|² = $det, expected 1.0"
        }
        require(source.dim == target.dim) { "Source/target dimensions must match" }
    }

    /**
     * §T|CHANNEL: Apply the Möbius transformation to a disk point.
     * For dim > 2, acts per 2D slice. For dim == 1, degenerates to identity.
     *
     * Orientation flip (ρ involution) is conjugation of the complex result
     * when [orientation] is true. By A5 two applications cancel.
     */
    fun traverse(x: FloatArray): FloatArray {
        require(x.size == source.dim) { "Input dim must match source.dim" }
        val out = FloatArray(x.size)
        var i = 0
        while (i < x.size - 1) {
            val zRe = x[i]
            val zIm = x[i + 1]
            // numerator  = a·z + b̄
            val numRe = aRe * zRe - aIm * zIm + bRe
            val numIm = aRe * zIm + aIm * zRe - bIm  // b̄ has −bIm
            // denominator = b·z + ā
            val denRe = bRe * zRe - bIm * zIm + aRe
            val denIm = bRe * zIm + bIm * zRe - aIm  // ā has −aIm
            val denNorm = denRe * denRe + denIm * denIm
            val safeDen = if (denNorm < 1e-12f) 1e-12f else denNorm
            // (num * conj(den)) / |den|²
            var outRe = (numRe * denRe + numIm * denIm) / safeDen
            var outIm = (numIm * denRe - numRe * denIm) / safeDen
            if (orientation) outIm = -outIm  // ρ flip: conjugate
            out[i] = outRe
            out[i + 1] = outIm
            i += 2
        }
        // Odd tail: pass through (no complex pair to act on)
        if (i < x.size) out[i] = x[i]
        // Rescale curvature if source and target differ (A29: c_k → c_{k+1})
        return rescaleCurvature(out)
    }

    /**
     * §T|CHANNEL: Rescale the point from source.curvature to target.curvature.
     * In the Poincaré model, c enters as |x|_c = |x|_1 · √(c_src/c_tgt) at
     * infinitesimal level; apply radial scaling to match.
     */
    private fun rescaleCurvature(x: FloatArray): FloatArray {
        if (abs(source.curvature - target.curvature) < 1e-6f) return target.project(x)
        val factor = sqrt(source.curvature / target.curvature)
        val rescaled = FloatArray(x.size) { x[it] * factor }
        return target.project(rescaled)
    }

    /**
     * §T|CHANNEL: Return the inverse channel (target → source).
     * For SU(1,1) element (a, b), inverse is (ā, −b); orientation preserved
     * modulo the ρ involution.
     */
    fun inverse(): MobiusChannel = MobiusChannel(
        source = target,
        target = source,
        aRe = aRe,
        aIm = -aIm,     // conjugate
        bRe = -bRe,
        bIm = -bIm,
        orientation = orientation
    )

    /**
     * §T|CHANNEL: Flip orientation (ρ involution). Applying this twice returns
     * the original channel (A5: ρ∘ρ = id).
     */
    fun flipped(): MobiusChannel = MobiusChannel(
        source, target, aRe, aIm, bRe, bIm, !orientation
    )

    /**
     * §T|CHANNEL: Round-trip test per INTER_MANIFOLD.two_traverses.
     * Returns the drift ||x − inverse(traverse(x))|| measured in source metric.
     * Should be ~0 up to numerical error for well-formed SU(1,1) elements.
     */
    fun roundTripDrift(x: FloatArray): Float {
        val forward = traverse(x)
        val back = inverse().traverse(forward)
        return source.distance(x, back)
    }

    companion object {
        /**
         * §T|CHANNEL: Construct an elliptic Möbius (rotation about origin by angle θ).
         * a = e^{iθ/2}, b = 0. Used for clock-phase rotation in peer sync.
         */
        fun elliptic(
            source: PoincareDisk,
            target: PoincareDisk,
            theta: Float,
            orientation: Boolean = false
        ): MobiusChannel {
            val half = theta / 2f
            return MobiusChannel(
                source, target,
                aRe = cos(half), aIm = sin(half),
                bRe = 0f, bIm = 0f,
                orientation = orientation
            )
        }

        /**
         * §T|CHANNEL: Construct a hyperbolic Möbius (translation along real axis
         * by hyperbolic distance d). Used for inter-level lift/proj where
         * structural translation is the natural transport.
         */
        fun hyperbolic(
            source: PoincareDisk,
            target: PoincareDisk,
            d: Float,
            orientation: Boolean = false
        ): MobiusChannel {
            val c = cosh((d / 2f).toDouble()).toFloat()
            val s = sinh((d / 2f).toDouble()).toFloat()
            return MobiusChannel(
                source, target,
                aRe = c, aIm = 0f,
                bRe = s, bIm = 0f,
                orientation = orientation
            )
        }

        /**
         * §T|CHANNEL: Identity channel between disks (no transform beyond
         * curvature rescale). Useful as seed before training/fitting.
         */
        fun identity(
            source: PoincareDisk,
            target: PoincareDisk,
            orientation: Boolean = false
        ): MobiusChannel = MobiusChannel(
            source, target,
            aRe = 1f, aIm = 0f,
            bRe = 0f, bIm = 0f,
            orientation = orientation
        )
    }
}
