package com.example.topostrasgo.unified

import kotlin.math.*

/**
 * §T|SCREEN: Per-level holographic boundary screen realizing §|DIALECT_TOWER|
 * HOLO_SCREEN_EXT. The Gromov boundary of the Poincaré disk is S¹; this class
 * discretizes it into `numSectors` angular buckets, each holding a `payloadDim`
 * -dimensional measure vector.
 *
 * Two adjoint maps connect bulk and boundary:
 *   commit(bulk → boundary) = Poisson extension at the boundary limit
 *   read  (boundary → bulk) = sample of boundary measure at geodesic-aim angle
 *
 * The collar parameter enforces that `commit` operates only near the boundary
 * (|x| ≥ 1 − collarEps/√c) where the horocyclic limit is numerically stable.
 * Bulk points deeper in the interior are reflected out to the collar first.
 *
 * Corresponds to §|DIALECT_TOWER|SORTS_EXT sort.Screen_k.
 */
class HolographicBoundary(
    val disk: PoincareDisk,
    val numSectors: Int = 64,
    val payloadDim: Int = 8,
    val collarEps: Float = 0.001f
) {
    /** §T|SCREEN: Angular bucket measures. sectors[k] = measure at angle 2πk/N. */
    private val sectors: Array<FloatArray> = Array(numSectors) { FloatArray(payloadDim) }

    /** §T|SCREEN: Per-sector occupancy count — for normalization on read. */
    private val counts: IntArray = IntArray(numSectors)

    init {
        require(numSectors > 0) { "numSectors must be positive" }
        require(payloadDim > 0) { "payloadDim must be positive" }
        require(disk.dim >= 2) { "Disk must be at least 2D for S¹ boundary to make sense" }
    }

    /**
     * §T|SCREEN: Geodesic limit — project bulk point to its boundary angle.
     * For a point x in the disk, the geodesic through the origin in direction
     * x/|x| hits S¹ at angle atan2(x[1], x[0]). Full Busemann-based projection
     * for off-origin geodesics is a TODO (PT5 in Tower dialect).
     */
    fun projectToAngle(bulk: FloatArray): Float {
        require(bulk.size == disk.dim) { "Bulk point must match disk dim" }
        return atan2(bulk[1], bulk[0])
    }

    /**
     * §T|SCREEN: Angle → sector index. Wraps [0, 2π) → [0, numSectors).
     */
    fun angleToSector(angle: Float): Int {
        val twoPi = 2f * PI.toFloat()
        var a = angle % twoPi
        if (a < 0f) a += twoPi
        return ((a / twoPi) * numSectors).toInt().coerceIn(0, numSectors - 1)
    }

    /**
     * §T|SCREEN: Commit a payload at the boundary limit of `bulk`.
     *
     * Implements the Poisson-extension-side adjoint: a bulk point injects
     * its payload weighted by its own hyperbolic depth (Busemann function).
     * Points near the boundary write with weight ~1; points near origin
     * write with weight ~0 (they're equidistant from all boundary points).
     */
    fun commit(bulk: FloatArray, payload: FloatArray) {
        require(payload.size == payloadDim) { "Payload dim mismatch" }
        val angle = projectToAngle(bulk)
        val sector = angleToSector(angle)
        // Busemann-weighted deposit: weight = 1 - (1 - |x|²)·c (proxy for depth)
        val r2 = HyperbolicOps.dot(bulk, bulk)
        val weight = 1f - (1f - disk.curvature * r2).coerceIn(0f, 1f)
        for (i in 0 until payloadDim) {
            sectors[sector][i] += weight * payload[i]
        }
        counts[sector] += 1
    }

    /**
     * §T|SCREEN: Read the average measure at a boundary angle.
     * Returns zero vector if the sector has never been committed to.
     */
    fun read(angle: Float): FloatArray {
        val sector = angleToSector(angle)
        val c = counts[sector]
        if (c == 0) return FloatArray(payloadDim)
        return FloatArray(payloadDim) { i -> sectors[sector][i] / c.toFloat() }
    }

    /**
     * §T|SCREEN: Poisson extension — given a boundary angle and its measure,
     * produce a bulk distribution (point + weight field over the disk).
     *
     * Poisson kernel P(x, ξ) = (1 − |x|²) / |x − ξ|² on Euclidean disk;
     * for Poincaré ball at curvature c, scale radii accordingly. We emit
     * a point in the collar aimed at `angle` with the supplied weight —
     * the full kernel integral is deferred to PT5.
     */
    fun poissonExtend(angle: Float, weight: Float = 1f): FloatArray {
        val r = (1f - collarEps) / sqrt(disk.curvature)
        val bulk = FloatArray(disk.dim)
        bulk[0] = r * cos(angle) * weight
        bulk[1] = r * sin(angle) * weight
        return disk.project(bulk)
    }

    /**
     * §T|SCREEN: Clear all sectors (for rollback verdicts / testing).
     */
    fun clear() {
        for (s in sectors) s.fill(0f)
        counts.fill(0)
    }

    /**
     * §T|SCREEN: Total occupancy across all sectors — σ7-style `h_emit_nonempty`
     * variant. Used by the outer loop to gate COMMIT on screen content.
     */
    fun totalOccupancy(): Int = counts.sum()

    /**
     * §T|SCREEN: Spectral diversity over angular sectors — entropy of the
     * occupancy distribution. Flat angular distribution ⇒ high diversity.
     * Contributes to σ2 (spectral_diversity) evaluation at the boundary.
     */
    fun angularEntropy(): Float {
        val total = counts.sum()
        if (total == 0) return 0f
        var h = 0f
        for (c in counts) {
            if (c > 0) {
                val p = c.toFloat() / total.toFloat()
                h -= p * ln(p)
            }
        }
        return h / ln(numSectors.toFloat())  // normalized to [0, 1]
    }

    /**
     * §T|SCREEN: Snapshot current sector state as immutable copy. For residue
     * extraction in §|DIALECT_TOWER|COMPRESS axis "screen_boundary_traces".
     */
    fun snapshot(): Array<FloatArray> =
        Array(numSectors) { k -> sectors[k].copyOf() }
}
